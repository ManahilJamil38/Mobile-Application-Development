import "react-native-gesture-handler";
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";

import StackNavigator from "./frontend/navigation/StackNavigator";

export default function App() {
  const [fontsLoaded] = useFonts({
    "Roboto-Light": require("./assets/fonts/RobotoCondensed-Light.ttf"),
  });

  if (!fontsLoaded) return null;

  return (
    <NavigationContainer>
      <StackNavigator />
    </NavigationContainer>
  );
}
// ============================================================
//  APP.JS — USE STATE NAVIGATION (Alternative Version)
// ============================================================
//  Flow:  Home → button → Profile / Settings / Contact
//  screen state track karti hai — conditional rendering
// ============================================================

// import React, { useState } from "react";
// import { View } from "react-native";
// import { useFonts } from "expo-font";

// import HomeScreen from "./frontend/screens/HomeScreen";
// import ProfileScreen from "./frontend/screens/ProfileScreen";
// import SettingsScreen from "./frontend/screens/SettingsScreen";
// import ContactScreen from "./frontend/screens/ContactScreen";

// export default function App() {
//   const [screen, setScreen] = useState("home");

//   const [fontsLoaded] = useFonts({
//     "Roboto-Light": require("./assets/fonts/RobotoCondensed-Light.ttf"),
//   });

//   if (!fontsLoaded) return null;

//   if (screen === "profile") return <ProfileScreen goBack={() => setScreen("home")} />;
//   if (screen === "settings") return <SettingsScreen goBack={() => setScreen("home")} />;
//   if (screen === "contact") return <ContactScreen goBack={() => setScreen("home")} />;

//   return (
//     <HomeScreen
//       goProfile={() => setScreen("profile")}
//       goSettings={() => setScreen("settings")}
//       goContact={() => setScreen("contact")}
//     />
//   );
// }