
import { StyleSheet } from 'react-native';

export const colors = {
  background: '#F5F1E8',
  primary: '#254638',
  text: '#222222',
  secondaryText: '#777777',
  white: '#FFFFFF',
  border: '#D9D4C8',
};

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
  },

  subtitle: {
    fontSize: 16,
    color: colors.secondaryText,
  },

  button: {
    backgroundColor: colors.primary,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },

  buttonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: 'bold',
  },

  input: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    marginVertical: 8,
  },
});
