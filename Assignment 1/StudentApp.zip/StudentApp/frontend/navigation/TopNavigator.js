import React from "react";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";

import ProfileScreen from "../screens/ProfileScreen";
import SettingsScreen from "../screens/SettingsScreen";
import ContactScreen from "../screens/ContactScreen";

const Tab = createMaterialTopTabNavigator();

export default function TopNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: "#6C63FF",
        tabBarInactiveTintColor: "#888",
        tabBarLabelStyle: { fontSize: 14, fontWeight: "bold" },
        tabBarIndicatorStyle: { backgroundColor: "#6C63FF", height: 3 },
        tabBarStyle: { backgroundColor: "#fff" },
      }}
    >
      <Tab.Screen name="Profile"  component={ProfileScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
      <Tab.Screen name="Contact"  component={ContactScreen} />
    </Tab.Navigator>
  );
}