import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { GlobalStyles } from "../styles/GlobalStyles";

export default function ContactScreen({ navigation }) {
  const [email, setEmail] = useState("");

  return (
    <View style={[GlobalStyles.container, { backgroundColor: "#fff8f0" }]}>
      <View style={GlobalStyles.card}>
        <Text style={GlobalStyles.title}>Contact Us</Text>

        <View style={{ flexDirection: "row", alignItems: "center", width: "85%", marginVertical: 8 }}>
          <Ionicons name="mail" size={24} color="#6C63FF" style={{ marginRight: 8 }} />
          <TextInput
            style={[GlobalStyles.input, { flex: 1, marginVertical: 0 }]}
            placeholder="Enter your email"
            value={email}
            onChangeText={setEmail}
            inputMode="email"
            keyboardType="email-address"
          />
        </View>

        <TouchableOpacity
          style={GlobalStyles.button}
          onPress={() => Alert.alert("✅ Submitted", `Email: ${email}`)}
        >
          <Text style={GlobalStyles.buttonText}>Submit</Text>
        </TouchableOpacity>

        <TouchableOpacity style={GlobalStyles.button} onPress={() => navigation.goBack()}>
          <Text style={GlobalStyles.buttonText}>⬅  Back</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}