import React from "react";
import { View, Text, TouchableOpacity, ImageBackground } from "react-native";
import { GlobalStyles } from "../styles/GlobalStyles";

export default function HomeScreen({ navigation }) {
  return (
    <ImageBackground
      source={{ uri: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=1200" }}
      style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
      imageStyle={{ opacity: 0.85 }}
    >
      <View style={[GlobalStyles.card, { backgroundColor: "rgba(255,255,255,0.95)" }]}>
        <Text style={GlobalStyles.title}>🎓 Student App</Text>
        <Text style={GlobalStyles.subtitle}>Welcome to my assignment</Text>

        <TouchableOpacity
          style={GlobalStyles.button}
          onPress={() => navigation.navigate("MainTabs")}
        >
          <Text style={GlobalStyles.buttonText}>🚀 Explore App</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}