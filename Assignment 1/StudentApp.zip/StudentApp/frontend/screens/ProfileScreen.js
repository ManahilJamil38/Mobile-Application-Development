import React, { useState } from "react";
import { View, Text, TextInput, Image, TouchableOpacity } from "react-native";
import { GlobalStyles } from "../styles/GlobalStyles";

export default function ProfileScreen({ navigation }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");

  return (
    <View style={[GlobalStyles.container, { backgroundColor: "#f9f9ff" }]}>
      <View style={GlobalStyles.card}>
        <Image
          source={{ uri: "https://i.pravatar.cc/200?img=12" }}
          style={{ width: 100, height: 100, borderRadius: 50, marginBottom: 12 }}
        />
        <Text style={GlobalStyles.title}>Profile</Text>

        <TextInput
          style={GlobalStyles.input}
          placeholder="Enter your name"
          value={name}
          onChangeText={setName}
          inputMode="text"
          keyboardType="default"
        />

        <TextInput
          style={GlobalStyles.input}
          placeholder="Enter your age"
          value={age}
          onChangeText={setAge}
          inputMode="numeric"
          keyboardType="number-pad"
        />

        <Text style={GlobalStyles.subtitle}>
          👋 Hello {name || "..."}, you are {age || "..."} years old
        </Text>

        <TouchableOpacity style={GlobalStyles.button} onPress={() => navigation.goBack()}>
           <Text style={GlobalStyles.buttonText}>⬅  Back</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}