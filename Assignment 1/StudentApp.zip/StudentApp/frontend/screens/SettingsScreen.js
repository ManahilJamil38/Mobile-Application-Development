import React, { useState } from "react";
import { View, Text, Switch, TouchableOpacity } from "react-native";
import { GlobalStyles } from "../styles/GlobalStyles";

export default function SettingsScreen({ navigation }) {
  const [isDark, setIsDark] = useState(false);

  return (
    <View style={[GlobalStyles.container, { backgroundColor: isDark ? "#1a1a2e" : "#f0f4ff" }]}>
      <View style={[GlobalStyles.card, { backgroundColor: isDark ? "#16213e" : "#fff" }]}>
        <Text style={[GlobalStyles.title, { color: isDark ? "#fff" : "#2c3e50" }]}>
          Settings
        </Text>
        <Text style={[GlobalStyles.subtitle, { color: isDark ? "#ddd" : "#555" }]}>
          {isDark ? "🌙 Dark Mode ON" : "☀️ Light Mode ON"}
        </Text>
        <Switch
          value={isDark}
          onValueChange={setIsDark}
          trackColor={{ false: "#ccc", true: "#6C63FF" }}
          thumbColor={isDark ? "#fff" : "#f4f3f4"}
        />
        <TouchableOpacity style={GlobalStyles.button} onPress={() => navigation.goBack()}>
          <Text style={GlobalStyles.buttonText}>⬅  Back</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}