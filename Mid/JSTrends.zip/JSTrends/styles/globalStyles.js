import { StyleSheet, Platform } from 'react-native';

// Figma Exact Theme
export const colors = {
  background: '#F7F5F0',      // Figma jaisa soft cream
  primary: '#1F3B2C',         // Deep Forest Green
  text: '#1A1A1A',            // Soft Black
  secondaryText: '#7A7A7A',   // Grey text
  muted: '#B0B0B0',
  white: '#FFFFFF',
  border: '#E6E2D8',          // Soft beige borders
  softGreen: '#EAF0EB',       // Discount pill background
  danger: '#B54A3A',
};

// Figma jaisa elegant Serif font
export const fonts = {
  serif: Platform.OS === 'ios' ? 'Georgia' : 'serif',
};

export const globalStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scrollContent: { padding: 20, paddingBottom: 40 },
  logo: {
    fontFamily: fonts.serif,
    fontSize: 22,
    letterSpacing: 2,
    color: colors.primary,
    textAlign: 'center',
    fontWeight: '700',
  },
  title: {
    fontFamily: fonts.serif,
    fontSize: 32,
    color: colors.text,
    lineHeight: 38,
    fontWeight: '400',
  },
  subtitle: { fontSize: 14, color: colors.secondaryText, marginTop: 6, lineHeight: 20 },
  sectionTitle: {
    fontFamily: fonts.serif,
    fontSize: 22,
    color: colors.text,
    fontWeight: '600',
  },
  label: {
    fontSize: 11,
    letterSpacing: 1.5,
    color: colors.secondaryText,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  price: { fontSize: 15, fontWeight: '600', color: colors.text, marginTop: 4 },
  muted: { fontSize: 12, color: colors.secondaryText },
  // Buttons
  button: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: { color: colors.white, fontSize: 15, fontWeight: '500', letterSpacing: 0.5 },
  // Inputs
  input: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 14,
    color: colors.text,
    marginTop: 8,
  },
  inputLabel: { fontSize: 13, color: colors.text, fontWeight: '600', marginTop: 16 },
  // Info Box (Discount box)
  infoBox: {
    backgroundColor: colors.softGreen,
    borderRadius: 8,
    padding: 16,
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#D3E0D6',
  },
  infoText: { fontSize: 13, color: colors.primary, lineHeight: 20 },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 20 },
});