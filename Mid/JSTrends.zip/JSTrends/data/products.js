// J&S Trends - Local Products Data

export const accessories = {
  male: {
    purses: [
      { id: 'm-purse-1', name: 'The leather bifold', sub: 'Cognac / Pebbled leather', price: 850,
        image: 'https://i.pinimg.com/736x/33/20/b2/3320b209811ef15c001593894dce257c.jpg' },
      { id: 'm-purse-2', name: 'Slim card wallet', sub: 'Chocolate / Six slots', price: 700,
        image: 'https://i.pinimg.com/736x/9b/e7/80/9be7803639cf9425be59d3b4a7c862a3.jpg' },
      { id: 'm-purse-3', name: 'Classic leather wallet', sub: 'Black / Premium leather', price: 950,
        image: 'https://i.pinimg.com/736x/72/63/b7/7263b7c5f87972db9c8b5fd74553d539.jpg' },
      { id: 'm-purse-4', name: 'Minimalist card holder', sub: 'Tan / Leather', price: 600,
        image: 'https://i.pinimg.com/1200x/dc/b3/94/dcb394b7052c4497beb004fba2758ae8.jpg' },
    ],
    watches: [
      { id: 'm-watch-1', name: 'Everyday leather watch', sub: 'Gold / Brown leather', price: 900,
        image: 'https://i.pinimg.com/736x/65/30/63/6530634c4b73ec338b8f685bc6871e85.jpg' },
      { id: 'm-watch-2', name: 'The silver mesh', sub: 'Silver / Stainless steel', price: 1450,
        image: 'https://i.pinimg.com/1200x/4d/39/d1/4d39d1f5b3708a16732490d82945b22f.jpg' },
      { id: 'm-watch-3', name: 'The midnight watch', sub: 'Noir / Leather strap', price: 1250,
        image: 'https://i.pinimg.com/736x/c6/18/a7/c618a77503ce4e961e232e93da41d3c6.jpg' },
      { id: 'm-watch-4', name: 'The tan classic', sub: 'Tan / Leather strap', price: 1100,
        image: 'https://i.pinimg.com/736x/f7/9e/e6/f79ee67f3249b8d5dff7b2610c2e9b09.jpg' },
    ],
  },
  female: {
    jewellery: [
      { id: 'f-jew-1', name: 'Sculpted gold hoops', sub: 'Gold tone / Pair', price: 750,
        image: 'https://i.pinimg.com/736x/20/bb/62/20bb62dc5774f26d994fc08bc49cb91d.jpg' },
      { id: 'f-jew-2', name: 'Petite pearl drops', sub: 'Ivory / Gold tone', price: 950,
        image: 'https://i.pinimg.com/736x/30/c0/ae/30c0aee35cd5532134e9818596f3cda4.jpg' },
      { id: 'f-jew-3', name: 'Minimal gold necklace', sub: 'Gold / Chain', price: 1200,
        image: 'https://i.pinimg.com/1200x/aa/48/2d/aa482da8318e6a35ab2bb21489f55a8a.jpg' },
      { id: 'f-jew-4', name: 'Everyday gold ring', sub: 'Gold / Adjustable', price: 800,
        image: 'https://i.pinimg.com/736x/79/2a/ab/792aab8f4168a17352e765013646e13b.jpg' },
    ],
    purses: [
      { id: 'f-purse-1', name: 'The mini shoulder bag', sub: 'Forest / Vegan leather', price: 1800,
        image: 'https://i.pinimg.com/1200x/a3/44/52/a34452388e3d146d3ae7c9e06dc22e50.jpg' },
      { id: 'f-purse-2', name: 'Soft saddle purse', sub: 'Cognac / Adjustable strap', price: 1650,
        image: 'https://i.pinimg.com/736x/98/07/59/980759621e13fe4fc75d886739c30afe.jpg' },
      { id: 'f-purse-3', name: 'Classic black tote', sub: 'Black / Leather', price: 2200,
        image: 'https://i.pinimg.com/736x/61/62/2c/61622cff5436806c4fafeeb79887ffc4.jpg' },
      { id: 'f-purse-4', name: 'Mini crossbody', sub: 'Beige / Chain strap', price: 1950,
        image: 'https://i.pinimg.com/736x/ab/bb/be/abbbbe31bcbbeac8b882de4834fcc201.jpg' },
    ],
  },
};

export const clothes = {
  male: {
    stitched: [
      { id: 'm-st-1', name: 'Everyday cotton kurta', sub: 'Sand / S–XL', price: 2400,
        image: 'https://i.pinimg.com/1200x/23/e4/eb/23e4eb151779089ef4d9f92df422335b.jpg' },
      { id: 'm-st-2', name: 'Textured kurta set', sub: 'Olive / S–XL', price: 3200,
        image: 'https://i.pinimg.com/736x/83/d5/3d/83d53d5ae8da9da4d1156d59ec1fac05.jpg' },
      { id: 'm-st-3', name: 'Classic white shirt', sub: 'White / Cotton', price: 1800,
        image: 'https://i.pinimg.com/1200x/dd/2a/91/dd2a91dc1e3820641896c93e08a03e9a.jpg' },
      { id: 'm-st-4', name: 'Premium wash & wear', sub: 'Charcoal / Cotton', price: 2100,
        image: 'https://i.pinimg.com/736x/93/aa/46/93aa467ed91b5bb1c1bd3d0f6fd00296.jpg' },
    ],
    unstitched: [
      { id: 'm-un-1', name: 'Pure cotton fabric', sub: 'Sand / 4.5 metres', price: 1600,
        image: 'https://i.pinimg.com/736x/46/38/bb/4638bb9d0ae9fae8292681805a8b7ca7.jpg' },
      { id: 'm-un-2', name: 'Classic wash & wear', sub: 'Charcoal / 4.5 metres', price: 1900,
        image: 'https://i.pinimg.com/1200x/00/60/57/006057c3c7d813fc2a4cd10c4678fd71.jpg' },
      { id: 'm-un-3', name: 'Premium linen', sub: 'Beige / 4 metres', price: 2200,
        image: 'https://i.pinimg.com/1200x/69/39/3c/69393c8ae1e05a32edc7a324427bbf95.jpg' },
      { id: 'm-un-4', name: 'Summer cotton blend', sub: 'Off-white / 4.5 metres', price: 1700,
        image: 'https://i.pinimg.com/736x/9d/39/23/9d3923b19d20e2d683b83c482a1a66b3.jpg' },
    ],
  },
  female: {
    stitched: [
      { id: 'f-st-1', name: 'Embroidered kurta set', sub: 'Ivory / XS–XL', price: 3600,
        image: 'https://i.pinimg.com/736x/43/c1/80/43c180381d30e53a9551f29caa94695b.jpg' },
      { id: 'f-st-2', name: 'The relaxed two-piece', sub: 'Sage / XS–XL', price: 2800,
        image: 'https://i.pinimg.com/736x/2e/c0/bb/2ec0bb1c56952ce77baadff32ad2113f.jpg' },
      { id: 'f-st-3', name: 'Floral summer dress', sub: 'Multi / XS–L', price: 3100,
        image: 'https://i.pinimg.com/736x/34/9f/63/349f63b5527c7912f61ccd6a9b4a2476.jpg' },
      { id: 'f-st-4', name: 'Classic formal suit', sub: 'Black / XS–L', price: 4500,
        image: 'https://i.pinimg.com/736x/23/3c/85/233c85a9b1f35e6afe2e10133c3218b7.jpg' },
    ],
    unstitched: [
      { id: 'f-un-1', name: 'Botanical lawn set', sub: 'Sage / Three-piece', price: 2200,
        image: 'https://i.pinimg.com/736x/b5/6a/6e/b56a6e031ac94d87bd1e247348ca8be2.jpg' },
      { id: 'f-un-2', name: 'Rose embroidered lawn', sub: 'Rose / Three-piece', price: 2600,
        image: 'https://i.pinimg.com/1200x/6d/9b/94/6d9b940fcf2633a87cb650c6a8dfbae9.jpg' },
      { id: 'f-un-3', name: 'Ivory jacquard set', sub: 'Ivory / Three-piece', price: 2400,
        image: 'https://i.pinimg.com/1200x/9f/71/c9/9f71c9cf600b47ed904d10536f56168a.jpg' },
      { id: 'f-un-4', name: 'Dusk printed lawn', sub: 'Dusk / Three-piece', price: 1950,
        image: 'https://i.postimg.cc/dLnj5N7C/Un4.png' },
    ],
  },
};

export const makeup = [
  { id: 'mk-1', name: 'Rose lip oil', sub: 'Rose / 6 ml', price: 600,
    description: 'A sheer rose tint with a glossy, cushion-soft finish.',
    image: 'https://images.unsplash.com/photo-1631214524020-7e18db9a8f92?w=600' },
  { id: 'mk-2', name: 'Soft cream blush', sub: 'Petal / 5 g', price: 1200,
    description: 'Buildable peach-pink colour with a soft, skin-like finish.',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600' },
  { id: 'mk-3', name: 'Daily glow serum', sub: 'Hydrating / 30 ml', price: 1400,
    description: 'A lightweight daily serum for fresh, dewy-looking skin.',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=600' },
  { id: 'mk-4', name: 'Berry lip oil', sub: 'Berry / 6 ml', price: 650,
    description: 'Sheer berry colour with a glossy, non-sticky finish.',
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=600' },
];

export const allLocalProducts = [
  ...accessories.male.purses, ...accessories.male.watches,
  ...accessories.female.jewellery, ...accessories.female.purses,
  ...clothes.male.stitched, ...clothes.male.unstitched,
  ...clothes.female.stitched, ...clothes.female.unstitched,
  ...makeup,
];

export const findProduct = (id) => allLocalProducts.find((p) => p.id === id);