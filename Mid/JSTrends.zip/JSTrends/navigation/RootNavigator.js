import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/globalStyles';

// Screens Import
import SplashScreen from '../screens/SplashScreen';
import HomeScreen from '../screens/HomeScreen';
import AccessoriesScreen from '../screens/AccessoriesScreen';
import ClothesScreen from '../screens/ClothesScreen';
import MakeupScreen from '../screens/MakeupScreen';
import ProductListScreen from '../screens/ProductListScreen';
import ProductDetailScreen from '../screens/ProductDetailScreen';
import CartScreen from '../screens/CartScreen';
import CheckoutScreen from '../screens/CheckoutScreen';
import OrderConfirmationScreen from '../screens/OrderConfirmationScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import FavoritesScreen from '../screens/FavoritesScreen'; // Discover ki jagah Favorites
import AccountScreen from '../screens/AccountScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

function Tabs() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.muted,
      tabBarStyle: { backgroundColor: colors.background, borderTopColor: colors.border, height: 62, paddingBottom: 8, paddingTop: 6 },
      tabBarLabelStyle: { fontSize: 11, fontWeight: '500' },
      tabBarIcon: ({ color }) => {
        let iconName;
        if (route.name === 'Home') iconName = 'home-outline';
        else if (route.name === 'Favourites') iconName = 'heart-outline';
        else if (route.name === 'Cart') iconName = 'cart-outline';
        else if (route.name === 'Account') iconName = 'person-outline';
        return <Ionicons name={iconName} size={22} color={color} />;
      },
    })}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Favourites" component={FavoritesScreen} />
      <Tab.Screen name="Cart" component={CartScreen} />
      <Tab.Screen name="Account" component={AccountScreen} />
    </Tab.Navigator>
  );
}

function DrawerMenu() {
  return (
    <Drawer.Navigator screenOptions={{ headerShown: false, drawerActiveTintColor: colors.primary, drawerInactiveTintColor: colors.text, drawerStyle: { backgroundColor: colors.background, width: 280 } }}>
      <Drawer.Screen name="MainTabs" component={Tabs} options={{ drawerLabel: 'Home' }} />
      <Drawer.Screen name="Accessories" component={AccessoriesScreen} options={{ drawerLabel: 'Accessories' }} />
      <Drawer.Screen name="Clothes" component={ClothesScreen} options={{ drawerLabel: 'Clothes' }} />
      <Drawer.Screen name="Makeup" component={MakeupScreen} options={{ drawerLabel: 'Makeup' }} />
    </Drawer.Navigator>
  );
}

export default function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="Splash">
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Main" component={DrawerMenu} />
      <Stack.Screen name="Accessories" component={AccessoriesScreen} />
      <Stack.Screen name="Clothes" component={ClothesScreen} />
      <Stack.Screen name="Makeup" component={MakeupScreen} />
      <Stack.Screen name="ProductList" component={ProductListScreen} />
      <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
      <Stack.Screen name="Checkout" component={CheckoutScreen} />
      <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}