import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import { accessories } from '../data/products';

export default function AccessoriesScreen({ navigation }) {
  const [gender, setGender] = useState('male');
  const data = accessories[gender];

  const subcats = gender === 'male'
    ? [{ key: 'purses', label: 'Purses/Wallets' }, { key: 'watches', label: 'Watches' }]
    : [{ key: 'jewellery', label: 'Jewellery' }, { key: 'purses', label: 'Purses' }];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={globalStyles.label}>ACCESSORIES</Text>
          <Text style={globalStyles.title}>The finishing touch.</Text>
          <Text style={globalStyles.subtitle}>Small details. A lasting impression.</Text>

          {/* Gender Toggle */}
          <View style={styles.toggle}>
            {['male', 'female'].map((g) => (
              <TouchableOpacity
                key={g}
                style={[styles.toggleBtn, gender === g && styles.toggleActive]}
                onPress={() => setGender(g)}
              >
                <Text style={[styles.toggleText, gender === g && styles.toggleTextActive]}>
                  {g === 'male' ? 'Male' : 'Female'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Subcategory chips */}
          <View style={styles.chips}>
            {subcats.map((s) => (
              <TouchableOpacity
                key={s.key}
                style={styles.chip}
                onPress={() => navigation.navigate('ProductList', { category: 'accessories', gender, sub: s.key })}
              >
                <Text style={styles.chipText}>{s.label} ↗</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Product grid */}
          {subcats.map((s) => (
            <View key={s.key} style={{ marginTop: 24 }}>
              <Text style={globalStyles.sectionTitle}>{s.label}</Text>
              <View style={styles.grid}>
                {data[s.key].map((p) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    width="48%"
                    onPress={() => navigation.navigate('ProductDetail', { id: p.id })}
                  />
                ))}
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  toggle: { flexDirection: 'row', backgroundColor: '#EDE7DA', borderRadius: 8, padding: 4, marginTop: 20 },
  toggleBtn: { flex: 1, paddingVertical: 12, alignItems: 'center', borderRadius: 6 },
  toggleActive: { backgroundColor: colors.primary },
  toggleText: { fontSize: 14, color: colors.secondaryText, fontWeight: '500' },
  toggleTextActive: { color: '#fff', fontWeight: '600' },
  chips: { flexDirection: 'row', gap: 10, marginTop: 16 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 8 },
  chipText: { fontSize: 13, color: colors.text },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
});