import React, { useState } from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet, Alert, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import PrimaryButton from '../components/PrimaryButton';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function CheckoutScreen({ navigation }) {
  const { items, subtotal, discount, total, clearCart } = useCart();
  const { user } = useAuth();

  // Form States
  const [name, setName] = useState(user ? user.name : '');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' ya 'card'
  const [error, setError] = useState('');

  const deliveryFee = 150; // Real-life delivery fee
  const finalTotal = total + deliveryFee;

  const placeOrder = () => {
    setError('');
    if (!name.trim()) return setError("Please enter your full name.");
    if (!phone.trim() || phone.length < 11) return setError("Please enter a valid 11-digit phone number.");
    if (!address.trim()) return setError("Please enter your complete delivery address.");

    Alert.alert(
      "Confirm Order",
      `Are you sure you want to place this order for Rs. ${finalTotal.toLocaleString()}?`,
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Confirm", 
          onPress: () => {
            clearCart(); 
            navigation.replace('OrderConfirmation', { 
              orderTotal: finalTotal, 
              orderId: 'JST-' + Math.floor(Math.random() * 10000),
              customerName: name,
              address: address
            });
          } 
        }
      ]
    );
  };

  if (items.length === 0) {
    navigation.goBack();
    return null;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        
        <Text style={globalStyles.title}>Checkout.</Text>
        <Text style={globalStyles.subtitle}>Please provide your delivery details.</Text>

        {/* 1. Delivery Details Form */}
        <Text style={[globalStyles.sectionTitle, { marginTop: 24, fontSize: 18 }]}>1. Delivery Details</Text>
        
        <Text style={globalStyles.inputLabel}>Full Name</Text>
        <TextInput style={globalStyles.input} value={name} onChangeText={setName} placeholder="Your name" />

        <Text style={globalStyles.inputLabel}>Phone Number</Text>
        <TextInput style={globalStyles.input} value={phone} onChangeText={setPhone} placeholder="03XX XXXXXXX" keyboardType="phone-pad" maxLength={11} />

        <Text style={globalStyles.inputLabel}>Complete Address</Text>
        <TextInput 
          style={[globalStyles.input, { height: 80, textAlignVertical: 'top' }]} 
          value={address} 
          onChangeText={setAddress} 
          placeholder="House no, Street, Area, City" 
          multiline 
        />

        {/* 2. Payment Method */}
        <Text style={[globalStyles.sectionTitle, { marginTop: 24, fontSize: 18 }]}>2. Payment Method</Text>
        
        <TouchableOpacity style={[styles.payBox, paymentMethod === 'cod' && styles.payActive]} onPress={() => setPaymentMethod('cod')}>
          <Ionicons name={paymentMethod === 'cod' ? "radio-button-on" : "radio-button-off"} size={20} color={colors.primary} />
          <Text style={styles.payText}>Cash on Delivery</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.payBox, paymentMethod === 'card' && styles.payActive]} onPress={() => setPaymentMethod('card')}>
          <Ionicons name={paymentMethod === 'card' ? "radio-button-on" : "radio-button-off"} size={20} color={colors.primary} />
          <Text style={styles.payText}>Credit / Debit Card (Demo)</Text>
        </TouchableOpacity>

        {/* 3. Order Summary */}
        <Text style={[globalStyles.sectionTitle, { marginTop: 24, fontSize: 18 }]}>3. Order Summary</Text>
        
        <View style={styles.summaryBox}>
          {items.map((item) => (
            <View key={item.id} style={styles.itemRow}>
              <Text style={styles.itemName}>{item.quantity}x {item.name}</Text>
              <Text style={styles.itemPrice}>Rs. {(item.price * item.quantity).toLocaleString()}</Text>
            </View>
          ))}
          <View style={globalStyles.divider} />
          
          <View style={styles.row}><Text style={globalStyles.muted}>Subtotal</Text><Text>Rs. {subtotal.toLocaleString()}</Text></View>
          <View style={styles.row}>
            <Text style={globalStyles.muted}>Discount</Text>
            <Text style={{ color: discount > 0 ? 'green' : colors.text }}>{discount > 0 ? `– Rs. ${discount.toLocaleString()}` : 'Rs. 0'}</Text>
          </View>
          <View style={styles.row}><Text style={globalStyles.muted}>Delivery Fee</Text><Text>Rs. {deliveryFee}</Text></View>
          
          <View style={[globalStyles.divider, { marginVertical: 10 }]} />
          <View style={styles.row}>
            <Text style={{ fontWeight: 'bold', fontSize: 16 }}>Total Payable</Text>
            <Text style={{ fontWeight: 'bold', fontSize: 16, color: colors.primary }}>Rs. {finalTotal.toLocaleString()}</Text>
          </View>
        </View>

        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <PrimaryButton 
          title={`Place Order — Rs. ${finalTotal.toLocaleString()}`} 
          onPress={placeOrder} 
          style={{ marginTop: 24 }} 
          icon="checkmark-circle-outline"
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  payBox: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 16, marginTop: 10, backgroundColor: '#fff' },
  payActive: { borderColor: colors.primary, backgroundColor: colors.softGreen },
  payText: { fontSize: 14, fontWeight: '600', color: colors.text, marginLeft: 10 },
  summaryBox: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 16, marginTop: 10 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  itemName: { fontSize: 13, color: colors.text, flex: 1, marginRight: 10 },
  itemPrice: { fontSize: 13, fontWeight: '600', color: colors.text },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  errorText: { color: 'red', fontSize: 13, marginTop: 12, fontWeight: '600', textAlign: 'center' },
});