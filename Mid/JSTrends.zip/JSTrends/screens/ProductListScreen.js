import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import { accessories, clothes } from '../data/products';

export default function ProductListScreen({ route, navigation }) {
  const { category, gender, sub } = route.params;
  const rawData = category === 'accessories' ? accessories[gender][sub] : clothes[gender][sub];

  const [sortVisible, setSortVisible] = useState(false);
  const [filterVisible, setFilterVisible] = useState(false);
  const [sortBy, setSortBy] = useState('none'); 
  const [filterBy, setFilterBy] = useState('all'); 

  // Working Sort & Filter Logic
  let displayData = [...rawData];
  if (filterBy === 'under1000') displayData = displayData.filter(p => p.price < 1000);
  if (filterBy === '1000to2000') displayData = displayData.filter(p => p.price >= 1000 && p.price <= 2000);
  if (filterBy === 'above2000') displayData = displayData.filter(p => p.price > 2000);

  if (sortBy === 'low-high') displayData.sort((a, b) => a.price - b.price);
  if (sortBy === 'high-low') displayData.sort((a, b) => b.price - a.price);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 30 }}>
        <Text style={globalStyles.label}>{category.toUpperCase()} / {gender.toUpperCase()}</Text>
        <Text style={globalStyles.title}>{sub.charAt(0).toUpperCase() + sub.slice(1)}</Text>
        <Text style={globalStyles.subtitle}>{displayData.length} products</Text>

        <View style={styles.toolbar}>
          <TouchableOpacity style={styles.filterBtn} onPress={() => setFilterVisible(true)}>
            <Ionicons name="options-outline" size={16} color={colors.text} />
            <Text style={styles.filterText}>Filter</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterBtn} onPress={() => setSortVisible(true)}>
            <Text style={styles.filterText}>Sort</Text>
            <Ionicons name="chevron-down" size={14} color={colors.text} />
          </TouchableOpacity>
        </View>

        <View style={styles.grid}>
          {displayData.map((p) => (
            <ProductCard key={p.id} product={p} width="48%" onPress={() => navigation.navigate('ProductDetail', { id: p.id })} />
          ))}
        </View>
      </ScrollView>

      {/* Sort Modal */}
      <Modal visible={sortVisible} transparent animationType="fade">
        <TouchableOpacity style={styles.modalBg} onPress={() => setSortVisible(false)}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Sort By</Text>
            <TouchableOpacity onPress={() => { setSortBy('low-high'); setSortVisible(false); }}><Text style={styles.modalItem}>Price: Low to High</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => { setSortBy('high-low'); setSortVisible(false); }}><Text style={styles.modalItem}>Price: High to Low</Text></TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Filter Modal */}
      <Modal visible={filterVisible} transparent animationType="fade">
        <TouchableOpacity style={styles.modalBg} onPress={() => setFilterVisible(false)}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Filter By</Text>
            <TouchableOpacity onPress={() => { setFilterBy('all'); setFilterVisible(false); }}><Text style={styles.modalItem}>Show All</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => { setFilterBy('under1000'); setFilterVisible(false); }}><Text style={styles.modalItem}>Under Rs. 1000</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => { setFilterBy('1000to2000'); setFilterVisible(false); }}><Text style={styles.modalItem}>Rs. 1000 - Rs. 2000</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => { setFilterBy('above2000'); setFilterVisible(false); }}><Text style={styles.modalItem}>Above Rs. 2000</Text></TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  toolbar: { flexDirection: 'row', gap: 10, marginTop: 16, marginBottom: 20 },
  filterBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingHorizontal: 14, paddingVertical: 8, backgroundColor: '#fff' },
  filterText: { fontSize: 13, color: colors.text },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalBox: { backgroundColor: '#fff', borderRadius: 12, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 16, color: colors.text },
  modalItem: { fontSize: 15, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#eee', color: colors.text },
});