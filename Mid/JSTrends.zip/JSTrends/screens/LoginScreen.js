import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import PrimaryButton from '../components/PrimaryButton';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation, route }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  // Agar user kisi product se aya hai
  const productId = route?.params?.productId;
  const apiProduct = route?.params?.apiProduct;

  const handleLogin = async () => {
    try {
      setError('');
      
      // Validations
      if (!email || !email.includes('@')) return setError("Please enter a valid email address.");
      if (!password || password.length < 6) return setError("Password must be at least 6 characters.");

      await login(email, password);
      
      // Login ke baad wapas usi product pe bhejo
      if (productId || apiProduct) {
        navigation.replace('ProductDetail', { id: productId, apiProduct: apiProduct });
      } else {
        navigation.goBack();
      }
    } catch (err) {
      setError(err.message || "Invalid credentials. Please try again.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: 20 }}>
          <Text style={globalStyles.label}>YOUR SELECTION IS SAFE</Text>
          <Text style={globalStyles.title}>Welcome back.</Text>
          <Text style={globalStyles.subtitle}>Sign in before adding to your bag.</Text>

          <Text style={globalStyles.inputLabel}>Email address</Text>
          <TextInput 
            style={globalStyles.input} 
            placeholder="sara@email.com" 
            value={email} 
            onChangeText={setEmail} 
            keyboardType="email-address" 
            autoCapitalize="none" 
          />

          <Text style={globalStyles.inputLabel}>Password</Text>
          <TextInput 
            style={globalStyles.input} 
            placeholder="Min 6 characters" 
            value={password} 
            onChangeText={setPassword} 
            secureTextEntry 
          />

          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          <PrimaryButton 
            title="Sign In" 
            onPress={handleLogin} 
            style={{ marginTop: 24 }} 
            icon="arrow-forward" 
          />

          <TouchableOpacity 
            onPress={() => navigation.navigate('Register', { productId, apiProduct })} 
            style={styles.bottomLink}
          >
            <Text style={styles.bottomText}>Don't have an account? <Text style={{ fontWeight: 'bold', color: colors.primary }}>Sign Up</Text></Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  errorText: { color: 'red', fontSize: 13, marginTop: 10, fontWeight: '600' },
  bottomLink: { marginTop: 24, alignItems: 'center' },
  bottomText: { color: colors.text, fontSize: 14 },
});