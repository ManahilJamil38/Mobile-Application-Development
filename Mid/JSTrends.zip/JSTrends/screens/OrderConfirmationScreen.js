import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import PrimaryButton from '../components/PrimaryButton';

export default function OrderConfirmationScreen({ route, navigation }) {
  const { orderTotal, orderId } = route.params;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center' }}>
      <ScrollView contentContainerStyle={{ padding: 24, alignItems: 'center', paddingTop: 60 }}>
        <View style={styles.iconWrap}>
          <Ionicons name="checkmark" size={40} color={colors.primary} />
        </View>
        <Text style={[globalStyles.label, { marginTop: 20 }]}>DEMO ORDER PLACED</Text>
        <Text style={[globalStyles.title, { textAlign: 'center', marginTop: 8 }]}>A lovely choice.</Text>
        <Text style={[globalStyles.subtitle, { textAlign: 'center', marginBottom: 30 }]}>Your JSTrends edit is confirmed. Here's a little reminder of what you chose.</Text>

        <View style={styles.receiptBox}>
          <View style={styles.receiptHeader}>
            <Text style={{ fontWeight: '600', color: colors.text }}>{orderId}</Text>
            <Text style={globalStyles.muted}>18 October 2026</Text>
          </View>
          <View style={globalStyles.divider} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={globalStyles.sectionTitle}>Final payable</Text>
            <Text style={globalStyles.sectionTitle}>Rs. {orderTotal.toLocaleString()}</Text>
          </View>
        </View>

        <View style={globalStyles.infoBox}>
          <Text style={globalStyles.infoText}>No payment was collected. This is a demo order. No real delivery is scheduled. Your bag is now empty.</Text>
        </View>

        <PrimaryButton title="Continue shopping" onPress={() => navigation.replace('Main', { screen: 'Home' })} icon="arrow-forward" style={{ width: '100%', marginTop: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  iconWrap: { width: 90, height: 90, borderRadius: 45, backgroundColor: colors.softGreen, alignItems: 'center', justifyContent: 'center' },
  receiptBox: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: 20, width: '100%', marginBottom: 20 },
  receiptHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
});