
import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/globalStyles';

export default function CategoryScreen({ route, navigation }) {
  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>
        {route.name}
      </Text>

      <Text style={[globalStyles.subtitle, { marginTop: 10 }]}>
        Explore our collection
      </Text>

      <TouchableOpacity
        style={[globalStyles.button, { marginTop: 25 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={globalStyles.buttonText}>
          Back
        </Text>
      </TouchableOpacity>
    </View>
  );
}
