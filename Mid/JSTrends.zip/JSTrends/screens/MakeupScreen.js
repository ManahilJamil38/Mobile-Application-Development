import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Image, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';

export default function MakeupScreen({ navigation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const fetchProducts = () => {
    setLoading(true);
    setError(false);
    fetch('https://dummyjson.com/products/category/beauty')
      .then((res) => res.json())
      .then((data) => {
        setProducts(data.products);
        setLoading(false);
      })
      .catch((err) => {
        setError(true);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        
        <Text style={globalStyles.label}>THE BEAUTY EDIT</Text>
        <Text style={globalStyles.title}>Your natural glow.</Text>
        <Text style={globalStyles.subtitle}>Live products fetched from our API.</Text>

        {loading && (
          <View style={{ alignItems: 'center', marginTop: 50 }}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[globalStyles.muted, { marginTop: 10 }]}>Fetching live products...</Text>
          </View>
        )}

        {error && !loading && (
          <View style={styles.errorBox}>
            <Ionicons name="warning-outline" size={30} color={colors.danger} />
            <Text style={styles.errorText}>Failed to load products. Please check your internet.</Text>
            <TouchableOpacity style={styles.retryBtn} onPress={fetchProducts}>
              <Text style={styles.retryText}>Try Again</Text>
            </TouchableOpacity>
          </View>
        )}

        {!loading && !error && (
          <View style={styles.grid}>
            {products.map((item) => (
              <TouchableOpacity 
                key={item.id} 
                style={styles.card} 
                activeOpacity={0.85}
                onPress={() => {
                  // API product ko id ki jagah poora object bhej rahe hain
                  navigation.navigate('ProductDetail', { apiProduct: item });
                }}
              >
                <Image source={{ uri: item.thumbnail }} style={styles.img} resizeMode="contain" />
                <Text numberOfLines={1} style={styles.name}>{item.title}</Text>
                <Text style={globalStyles.price}>Rs. {(item.price * 280).toLocaleString()}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginTop: 20 },
  card: { width: '48%', marginBottom: 20, backgroundColor: '#fff', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: colors.border },
  img: { width: '100%', height: 130, borderRadius: 8, marginBottom: 8 },
  name: { fontSize: 13, fontWeight: '600', color: colors.text, height: 36 },
  errorBox: { alignItems: 'center', marginTop: 40, padding: 20, backgroundColor: '#fff', borderRadius: 10, borderWidth: 1, borderColor: colors.border },
  errorText: { fontSize: 14, color: colors.text, textAlign: 'center', marginTop: 10, marginBottom: 16 },
  retryBtn: { backgroundColor: colors.primary, paddingHorizontal: 20, paddingVertical: 10, borderRadius: 6 },
  retryText: { color: '#fff', fontWeight: '600' },
});