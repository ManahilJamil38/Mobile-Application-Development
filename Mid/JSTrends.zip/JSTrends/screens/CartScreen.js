import React from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import PrimaryButton from '../components/PrimaryButton';
import QuantityStepper from '../components/QuantityStepper';
import { useCart } from '../context/CartContext';

export default function CartScreen({ navigation }) {
  const { items, increaseQty, decreaseQty, removeItem, subtotal, discount, total } = useCart();

  if (items.length === 0) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <Header />
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <View style={styles.emptyIcon}><Ionicons name="bag-outline" size={40} color={colors.primary} /></View>
          <Text style={[globalStyles.title, { textAlign: 'center', marginTop: 20 }]}>Room for something lovely.</Text>
          <Text style={[globalStyles.subtitle, { textAlign: 'center', marginBottom: 30 }]}>Your bag is empty. Explore the edit and find your new everyday favourite.</Text>
          <PrimaryButton title="Explore the collection" onPress={() => navigation.navigate('Main', { screen: 'Home' })} icon="arrow-forward" style={{ width: '100%' }} />
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20 }}>
        <Text style={globalStyles.label}>YOUR CONSIDERED COLLECTION</Text>
        <Text style={globalStyles.title}>In your bag.</Text>
        <Text style={globalStyles.subtitle}>{items.length} items, ready for a little everyday joy.</Text>

        <View style={{ marginTop: 20 }}>
          {items.map((item) => (
            <View key={item.id} style={styles.cartItem}>
              <Image source={{ uri: item.image }} style={styles.itemImg} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={globalStyles.muted}>{item.sub}</Text>
                <Text style={[globalStyles.price, { marginTop: 6 }]}>Rs. {item.price.toLocaleString()}</Text>
                <View style={{ marginTop: 10 }}>
                  <QuantityStepper quantity={item.quantity} onIncrease={() => increaseQty(item.id)} onDecrease={() => decreaseQty(item.id)} />
                </View>
              </View>
              <TouchableOpacity onPress={() => removeItem(item.id)} style={{ padding: 4 }}>
                <Ionicons name="trash-outline" size={20} color={colors.muted} />
              </TouchableOpacity>
            </View>
          ))}
        </View>

        <View style={globalStyles.divider} />

        {/* Price Details */}
        <View style={styles.row}><Text style={globalStyles.muted}>Subtotal · {items.length} items</Text><Text style={styles.priceText}>Rs. {subtotal.toLocaleString()}</Text></View>
        {discount > 0 && (
          <View style={styles.row}><Text style={globalStyles.muted}>October offer · 20%</Text><Text style={styles.priceText}>– Rs. {discount.toLocaleString()}</Text></View>
        )}
        <View style={[styles.row, { marginTop: 16 }]}>
          <Text style={globalStyles.sectionTitle}>Total</Text>
          <Text style={globalStyles.sectionTitle}>Rs. {total.toLocaleString()}</Text>
        </View>

        {discount > 0 && (
          <View style={globalStyles.infoBox}>
            <Text style={globalStyles.infoText}>Your bag qualifies for 20% off. Shopping above Rs. 1,200. Available till 20 October.</Text>
          </View>
        )}

        <PrimaryButton title="Continue to checkout" onPress={() => navigation.navigate('Checkout')} icon="arrow-forward" style={{ marginTop: 20 }} />
        <PrimaryButton title="Continue shopping" onPress={() => navigation.navigate('Main', { screen: 'Home' })} outline style={{ marginTop: 10 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cartItem: { flexDirection: 'row', marginBottom: 24 },
  itemImg: { width: 80, height: 100, borderRadius: 8, backgroundColor: '#EDE7DA' },
  itemName: { fontSize: 14, fontWeight: '600', color: colors.text },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  priceText: { fontSize: 14, fontWeight: '500', color: colors.text },
  emptyIcon: { width: 80, height: 80, borderRadius: 40, backgroundColor: colors.softGreen, alignItems: 'center', justifyContent: 'center' },
});