import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import PrimaryButton from '../components/PrimaryButton';
import { useAuth } from '../context/AuthContext';

export default function AccountScreen({ navigation }) {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Sign Out", style: "destructive", onPress: () => logout() }
    ]);
  };

  if (!user) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <Header showMenu />
        <View style={{ flex: 1, padding: 20, justifyContent: 'center' }}>
          <Text style={globalStyles.title}>Your space.</Text>
          <Text style={globalStyles.subtitle}>Sign in to view your profile and orders.</Text>
          <PrimaryButton title="Sign in" onPress={() => navigation.navigate('Login')} style={{ marginTop: 20 }} />
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showMenu />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={globalStyles.title}>Hello, {user.name}.</Text>
        <View style={styles.profileCard}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{user.name.charAt(0).toUpperCase()}</Text></View>
          <View>
            <Text style={{ fontSize: 16, fontWeight: '600', color: colors.text }}>{user.name}</Text>
            <Text style={globalStyles.muted}>{user.email}</Text>
          </View>
        </View>
        <PrimaryButton title="Sign out" onPress={handleLogout} outline style={{ marginTop: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  profileCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.softGreen, padding: 16, borderRadius: 10, marginTop: 20, gap: 16 },
  avatar: { width: 50, height: 50, borderRadius: 25, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
});