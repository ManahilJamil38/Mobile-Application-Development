import React, { useEffect } from 'react';
import { View, Text, ImageBackground, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/globalStyles';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    // 3 Seconds (3000ms) timer
    const t = setTimeout(() => navigation.replace('Main'), 3000);
    return () => clearTimeout(t);
  }, []);

  return (
    <ImageBackground
      source={{ uri: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800' }}
      style={styles.bg}
    >
      <StatusBar barStyle="light-content" />
      <View style={styles.overlay}>
        <View style={styles.top}>
          <Text style={styles.brandSmall}>J&S</Text>
          <Text style={styles.brand}>J&S Trends</Text>
          <Text style={styles.tagline}>THE EVERYDAY, ELEVATED</Text>
        </View>

        <View>
          <Text style={styles.headline}>Good things,{'\n'}beautifully chosen.</Text>
          
          <View style={styles.promoRow}>
            <Ionicons name="sparkles" size={16} color="#fff" />
            <Text style={styles.promo}>20% OFF — Limited Stock!</Text>
          </View>
          
          <TouchableOpacity style={styles.btn} onPress={() => navigation.replace('Main')}>
            <Text style={styles.btnText}>Explore J&S Trends</Text>
            <Ionicons name="arrow-forward" size={18} color="#fff" style={{ marginLeft: 8 }} />
          </TouchableOpacity>
          
          <Text style={styles.footer}>Fashion, accessories & beauty. Your way.</Text>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  overlay: { flex: 1, backgroundColor: 'rgba(20,30,24,0.65)', justifyContent: 'space-between', paddingHorizontal: 28, paddingTop: 80, paddingBottom: 50 },
  top: { alignItems: 'center' },
  brandSmall: { fontSize: 32, color: '#fff', fontFamily: 'Georgia' },
  brand: { fontSize: 24, letterSpacing: 4, color: '#fff', fontFamily: 'Georgia', marginTop: 4, fontWeight: '600' },
  tagline: { fontSize: 10, letterSpacing: 3, color: 'rgba(255,255,255,0.85)', marginTop: 10 },
  headline: { fontSize: 38, color: '#fff', fontFamily: 'Georgia', lineHeight: 44 },
  promoRow: { flexDirection: 'row', alignItems: 'center', marginTop: 16 },
  promo: { color: '#fff', fontSize: 14, marginLeft: 8 },
  btn: { backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, borderRadius: 8, marginTop: 24, borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)' },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  footer: { color: 'rgba(255,255,255,0.75)', fontSize: 12, textAlign: 'center', marginTop: 20 },
});