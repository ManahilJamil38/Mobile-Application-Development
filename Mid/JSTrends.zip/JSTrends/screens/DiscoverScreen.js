import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image, ActivityIndicator, StyleSheet } from 'react-native';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';

export default function DiscoverScreen() {
  // 1. Data save karne ke liye state
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // 2. API Call (Jab screen khulegi tab chalega)
  useEffect(() => {
    // Humne DummyJSON API use ki hai jo hamari categories se match karti hai
    fetch('https://dummyjson.com/products/category/womens-bags')
      .then((response) => response.json()) // Data ko JSON mein badla
      .then((data) => {
        setProducts(data.products); // Data ko state mein save kiya
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  }, []);

  // 3. Har product ka design
  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.thumbnail }} style={styles.img} resizeMode="contain" />
      <Text numberOfLines={1} style={styles.name}>{item.title}</Text>
      {/* USD ko PKR mein convert kiya (1 USD = 280 PKR) */}
      <Text style={globalStyles.price}>Rs. {(item.price * 280).toLocaleString()}</Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header />
      <View style={{ flex: 1, paddingHorizontal: 20 }}>
        <Text style={globalStyles.label}>DISCOVER / ONLINE COLLECTION</Text>
        <Text style={globalStyles.title}>A wider world.</Text>
        <Text style={globalStyles.subtitle}>A separate edit from our online collection.</Text>

        {/* Loading spinner jab tak data nahi aata */}
        {loading ? (
          <View style={{ flex: 1, justifyContent: 'center' }}>
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : (
          <FlatList
            data={products}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderItem}
            numColumns={2}
            columnWrapperStyle={{ justifyContent: 'space-between' }}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingVertical: 20 }}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { width: '48%', marginBottom: 24 },
  img: { width: '100%', height: 160, backgroundColor: '#fff', borderRadius: 10, marginBottom: 8 },
  name: { fontSize: 14, fontWeight: '600', color: colors.text },
});