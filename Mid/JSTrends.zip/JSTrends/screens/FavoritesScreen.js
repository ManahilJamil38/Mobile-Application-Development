import React from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions } from 'react-native';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import { useFavorites } from '../context/FavoritesContext';

const { width } = Dimensions.get('window');

export default function FavoritesScreen({ navigation }) {
  const { favorites } = useFavorites();

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showMenu />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20 }}>
        <Text style={globalStyles.title}>Your Favourites.</Text>
        <Text style={globalStyles.subtitle}>All the pieces you loved.</Text>

        {favorites.length === 0 ? (
          <View style={{ alignItems: 'center', marginTop: 50 }}>
            <Text style={globalStyles.subtitle}>No favourites yet. Tap the heart on any item to save it here.</Text>
          </View>
        ) : (
          <View style={styles.grid}>
            {favorites.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                width={(width - 60) / 2}
                onPress={() => navigation.navigate('ProductDetail', { id: p.id })}
              />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginTop: 20 },
});