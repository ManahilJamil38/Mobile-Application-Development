import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, TextInput, StyleSheet, Animated, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import { accessories, clothes, makeup, allLocalProducts } from '../data/products';

const { width } = Dimensions.get('window');

function MovingBanner() {
  const x = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(x, { toValue: -width * 1.4, duration: 9000, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, []);
  return (
    <View style={styles.banner}>
      <Animated.Text numberOfLines={1} style={[styles.bannerText, { transform: [{ translateX: x }] }]}>
        ✦ 20% OFF on Shopping Above Rs. 1,200 — Available Till 20 October ✦
      </Animated.Text>
    </View>
  );
}

export default function HomeScreen({ navigation }) {
  const [searchQuery, setSearchQuery] = useState('');
  const featured = [accessories.male.watches[0], makeup[2]];

  // SIRF 3 CATEGORIES KO MATCH KARNE KA LOGIC
  const searchResults = searchQuery.trim()
    ? allLocalProducts.filter((p) => {
        const query = searchQuery.toLowerCase().trim();
        
        // 1. Accessories
        if (query.includes('access')) {
          return p.id.startsWith('m-purse') || p.id.startsWith('m-watch') || p.id.startsWith('f-jew') || p.id.startsWith('f-purse');
        }
        // 2. Makeup
        if (query.includes('make')) {
          return p.id.startsWith('mk-');
        }
        // 3. Clothes
        if (query.includes('cloth')) {
          return p.id.includes('-st-') || p.id.includes('-un-');
        }
        // Agar kuch aur likha hai (jaise product ka naam)
        return p.name.toLowerCase().includes(query) || p.sub.toLowerCase().includes(query);
      })
    : [];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showMenu />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        
        {/* Search Bar */}
        <View style={styles.searchWrap}>
          <Ionicons name="search" size={18} color={colors.secondaryText} />
          <TextInput 
            placeholder="Search (e.g. Accessories, Makeup, Clothes)" 
            placeholderTextColor={colors.muted} 
            style={styles.search} 
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={18} color={colors.muted} />
            </TouchableOpacity>
          )}
        </View>

        {/* Results Section */}
        {searchQuery.trim().length > 0 ? (
          <View style={{ paddingHorizontal: 20, marginTop: 20 }}>
            <Text style={globalStyles.sectionTitle}>Search Results for "{searchQuery}"</Text>
            {searchResults.length === 0 ? (
              <Text style={[globalStyles.subtitle, { marginTop: 10 }]}>No products found.</Text>
            ) : (
              <View style={styles.grid}>
                {searchResults.map((p) => (
                  <ProductCard key={p.id} product={p} width={(width - 60) / 2} onPress={() => navigation.navigate('ProductDetail', { id: p.id })} />
                ))}
              </View>
            )}
          </View>
        ) : (
          // Default Home Screen
          <>
            <MovingBanner />
            <TouchableOpacity activeOpacity={0.9} style={styles.hero}>
              <Image source={{ uri: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800' }} style={styles.heroImg} />
              <View style={styles.heroOverlay}>
                <Text style={styles.heroLabel}>THE OCTOBER EDIT</Text>
                <Text style={styles.heroTitle}>A little less{'\n'}ordinary.</Text>
                <Text style={styles.heroCta}>Discover the collection →</Text>
              </View>
            </TouchableOpacity>

            <View style={styles.sectionHead}><Text style={globalStyles.sectionTitle}>Find your world</Text></View>
            <View style={styles.catRow}>
              {[
                { key: 'Accessories', label: 'Accessories', img: 'https://i.pinimg.com/736x/93/b8/80/93b880c1a0fe049019fbbc891849e51d.jpg' },
                { key: 'Clothes', label: 'Clothes', img: 'https://i.pinimg.com/1200x/96/8b/9f/968b9fe207a4dc5a10652e850313675e.jpg' },
                { key: 'Makeup', label: 'Makeup', img: 'https://i.pinimg.com/736x/48/41/57/484157005374758b1efccdf30cbd3bb8.jpg' },
              ].map((c) => (
                <TouchableOpacity key={c.key} style={styles.cat} onPress={() => navigation.navigate(c.key)}>
                  <Image source={{ uri: c.img }} style={styles.catImg} />
                  <Text style={styles.catLabel}>{c.label} ↗</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.sectionHead}><Text style={globalStyles.sectionTitle}>Everyday favourites</Text></View>
            <View style={styles.grid}>
              {featured.map((p) => (
                <ProductCard key={p.id} product={p} width={(width - 60) / 2} onPress={() => navigation.navigate('ProductDetail', { id: p.id })} />
              ))}
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  searchWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 8, paddingHorizontal: 14, paddingVertical: 12, marginHorizontal: 20, marginTop: 4, borderWidth: 1, borderColor: colors.border },
  search: { flex: 1, marginLeft: 8, fontSize: 13, color: colors.text },
  banner: { backgroundColor: colors.primary, marginHorizontal: 20, marginTop: 14, borderRadius: 8, paddingVertical: 14, overflow: 'hidden' },
  bannerText: { color: '#fff', fontSize: 13, fontWeight: '500', paddingLeft: 14 },
  hero: { marginHorizontal: 20, marginTop: 18, borderRadius: 12, overflow: 'hidden', height: 340 },
  heroImg: { width: '100%', height: '100%' },
  heroOverlay: { position: 'absolute', left: 0, right: 0, bottom: 0, top: 0, backgroundColor: 'rgba(20,30,24,0.3)', justifyContent: 'flex-end', padding: 20 },
  heroLabel: { color: '#fff', fontSize: 10, letterSpacing: 2, marginBottom: 6 },
  heroTitle: { color: '#fff', fontSize: 34, fontFamily: 'Georgia', lineHeight: 38 },
  heroCta: { color: '#fff', fontSize: 12, marginTop: 10 },
  sectionHead: { paddingHorizontal: 20, marginTop: 26, marginBottom: 14, flexDirection: 'row', justifyContent: 'space-between' },
  catRow: { flexDirection: 'row', paddingHorizontal: 20, gap: 10 },
  cat: { flex: 1 },
  catImg: { width: '100%', aspectRatio: 0.85, borderRadius: 10, backgroundColor: '#EDE7DA' },
  catLabel: { fontSize: 12, fontWeight: '600', color: colors.text, marginTop: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginTop: 15 },
});