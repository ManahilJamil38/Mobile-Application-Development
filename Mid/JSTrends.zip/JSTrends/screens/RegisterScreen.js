import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, StyleSheet } from 'react-native';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import PrimaryButton from '../components/PrimaryButton';
import { useAuth } from '../context/AuthContext';

export default function RegisterScreen({ navigation, route }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { signup } = useAuth();

  // Agar user kisi product se aya hai
  const productId = route?.params?.productId;
  const apiProduct = route?.params?.apiProduct;

  const handleRegister = async () => {
    try {
      setError('');
      
      // Validations
      if (!name.trim()) return setError("Please enter your name.");
      if (!email.includes('@')) return setError("Enter a valid email address.");
      if (password.length < 8) return setError("Password must be at least 8 characters.");

      await signup(name, email, password);
      
      // Register hone ke baad wapas product par bhejo (agar product se aya tha)
      if (productId || apiProduct) {
        navigation.replace('ProductDetail', { id: productId, apiProduct: apiProduct });
      } else {
        navigation.navigate('Main');
      }
    } catch (err) {
      setError(err.message || "Something went wrong.");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: 20 }}>
          <Text style={globalStyles.label}>A LITTLE MORE YOU</Text>
          <Text style={globalStyles.title}>Make yourself at home.</Text>
          <Text style={globalStyles.subtitle}>Create your account, then return to your item.</Text>

          <Text style={globalStyles.inputLabel}>Full name</Text>
          <TextInput style={globalStyles.input} placeholder="Your Name" value={name} onChangeText={setName} />

          <Text style={globalStyles.inputLabel}>Email address</Text>
          <TextInput style={globalStyles.input} placeholder="sara@email.com" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />

          <Text style={globalStyles.inputLabel}>Password</Text>
          <TextInput style={globalStyles.input} placeholder="Min 8 characters" value={password} onChangeText={setPassword} secureTextEntry />

          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          <PrimaryButton title="Sign Up" onPress={handleRegister} style={{ marginTop: 20 }} icon="arrow-forward" />

          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.bottomLink}>
            <Text style={styles.bottomText}>Already have an account? <Text style={{ fontWeight: 'bold', color: colors.primary }}>Sign In</Text></Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  errorText: { color: 'red', fontSize: 13, marginTop: 10, fontWeight: '600' },
  bottomLink: { marginTop: 20, alignItems: 'center' },
  bottomText: { color: colors.text, fontSize: 14 },
});