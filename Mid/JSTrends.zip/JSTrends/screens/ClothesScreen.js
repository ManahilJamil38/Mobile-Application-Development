import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import { clothes } from '../data/products';

const { width } = Dimensions.get('window');

export default function ClothesScreen({ navigation }) {
  const [gender, setGender] = useState('male');
  
  // Stitched aur Unstitched ki cover images
  const stitchedCover = clothes[gender].stitched[0].image;
  const unstitchedCover = clothes[gender].unstitched[0].image;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20 }}>
        
        <Text style={globalStyles.label}>CLOTHES</Text>
        <Text style={globalStyles.title}>Made for every day.</Text>
        <Text style={globalStyles.subtitle}>Considered fabrics. Effortless silhouettes.</Text>

        {/* Male / Female Toggle */}
        <View style={styles.toggle}>
          {['male', 'female'].map((g) => (
            <TouchableOpacity 
              key={g} 
              style={[styles.toggleBtn, gender === g && styles.toggleActive]} 
              onPress={() => setGender(g)}
            >
              <Text style={[styles.toggleText, gender === g && styles.toggleTextActive]}>
                {g === 'male' ? 'Male' : 'Female'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Stitched Card */}
        <TouchableOpacity 
          style={styles.bigCard} 
          onPress={() => navigation.navigate('ProductList', { category: 'clothes', gender, sub: 'stitched' })}
        >
          <Image source={{ uri: stitchedCover }} style={styles.cardImg} />
          <View style={styles.cardOverlay}>
            <Text style={styles.cardTitle}>Stitched Collection</Text>
            <View style={styles.cardArrow}>
              <Ionicons name="arrow-forward" size={20} color={colors.primary} />
            </View>
          </View>
        </TouchableOpacity>

        {/* Unstitched Card */}
        <TouchableOpacity 
          style={styles.bigCard} 
          onPress={() => navigation.navigate('ProductList', { category: 'clothes', gender, sub: 'unstitched' })}
        >
          <Image source={{ uri: unstitchedCover }} style={styles.cardImg} />
          <View style={styles.cardOverlay}>
            <Text style={styles.cardTitle}>Unstitched Collection</Text>
            <View style={styles.cardArrow}>
              <Ionicons name="arrow-forward" size={20} color={colors.primary} />
            </View>
          </View>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  toggle: { flexDirection: 'row', backgroundColor: '#EDE7DA', borderRadius: 8, padding: 4, marginTop: 20, marginBottom: 24 },
  toggleBtn: { flex: 1, paddingVertical: 12, alignItems: 'center', borderRadius: 6 },
  toggleActive: { backgroundColor: colors.primary },
  toggleText: { fontSize: 14, color: colors.secondaryText, fontWeight: '500' },
  toggleTextActive: { color: '#fff', fontWeight: '600' },
  
  bigCard: { 
    width: '100%', 
    height: 220, 
    borderRadius: 12, 
    overflow: 'hidden', 
    marginBottom: 20,
    backgroundColor: '#EDE7DA'
  },
  cardImg: { 
    width: '100%', 
    height: '100%',
    resizeMode: 'cover'
  },
  cardOverlay: { 
    position: 'absolute', 
    left: 0, right: 0, bottom: 0, 
    backgroundColor: 'rgba(255,255,255,0.9)', 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    padding: 16 
  },
  cardTitle: { 
    fontSize: 18, 
    fontWeight: '600', 
    color: colors.primary,
    fontFamily: 'Georgia'
  },
  cardArrow: {
    width: 32, height: 32,
    borderRadius: 16,
    backgroundColor: colors.softGreen,
    alignItems: 'center',
    justifyContent: 'center'
  }
});