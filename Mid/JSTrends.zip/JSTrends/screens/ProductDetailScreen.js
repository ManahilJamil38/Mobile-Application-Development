import React from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import Header from '../components/Header';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { findProduct } from '../data/products';

export default function ProductDetailScreen({ route, navigation }) {
  const { id, apiProduct } = route.params; 
  const { addToCart } = useCart();
  const { user } = useAuth();

  // Agar API product hai toh usko format karo, warna local dhoondo
  let product;
  if (apiProduct) {
    product = {
      id: apiProduct.id.toString(),
      name: apiProduct.title,
      sub: apiProduct.category,
      price: Math.round(apiProduct.price * 280), // USD to PKR
      image: apiProduct.thumbnail,
      description: apiProduct.description || 'A live product from our online API.',
    };
  } else {
    product = findProduct(id);
  }

  const handleAddToCart = () => {
    if (!user) {
      Alert.alert("Login Required", "Please login first to add items to your cart.", [{ text: "OK" }]);
      // Product detail par wapas aane ke liye hum id ya apiProduct sath bhej rahe hain
      navigation.navigate('Login', { returnTo: 'ProductDetail', productId: id, apiProduct: apiProduct });
      return;
    }
    addToCart(product);
    navigation.navigate('Main', { screen: 'Cart' });
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header showBack />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        <Image source={{ uri: product.image }} style={styles.image} />
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={[globalStyles.title, { marginTop: 16 }]}>{product.name}</Text>
          <Text style={globalStyles.price}>Rs. {product.price.toLocaleString()}</Text>
          <Text style={globalStyles.subtitle}>{product.sub}</Text>

          <Text style={styles.description}>
            {product.description || 'A quiet classic for every day. A considered finish to your wardrobe.'}
          </Text>

          <TouchableOpacity style={styles.addBtn} onPress={handleAddToCart}>
            <Text style={styles.addText}>Add to Cart — Rs. {product.price.toLocaleString()}</Text>
            <Ionicons name="add" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  image: { width: '100%', height: 380, backgroundColor: '#EDE7DA' },
  description: { fontSize: 14, color: colors.secondaryText, lineHeight: 22, marginTop: 16 },
  addBtn: { backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 16, borderRadius: 8, marginTop: 24 },
  addText: { color: '#fff', fontSize: 15, fontWeight: '600' },
});