import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { FavoritesProvider } from './context/FavoritesContext'; // <-- Ye import hona zaroori hai
import RootNavigator from './navigation/RootNavigator';

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AuthProvider>
        <CartProvider>
          <FavoritesProvider>  {/* <-- Ye wrap hona zaroori hai */}
            <NavigationContainer>
              <RootNavigator />
            </NavigationContainer>
          </FavoritesProvider>
        </CartProvider>
      </AuthProvider>
    </GestureHandlerRootView>
  );
}