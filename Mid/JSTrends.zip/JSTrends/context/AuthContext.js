import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext();
const USER_KEY = '@jstrends:currentUser';
const USERS_DB_KEY = '@jstrends:allUsers'; // Ye humara local database hai

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  // App start hone par check karo ke koi pehle se login hai ya nahi
  useEffect(() => {
    (async () => {
      const saved = await AsyncStorage.getItem(USER_KEY);
      if (saved) setUser(JSON.parse(saved));
    })();
  }, []);

  // 1. SIGNUP (Register)
  const signup = async (name, email, password) => {
    if (!name) throw new Error('Please enter your name.');
    if (!email.includes('@')) throw new Error('Enter a valid email.');
    if (password.length < 8) throw new Error('Password must be at least 8 characters.');

    // Purane saare users ka data nikaalo
    const savedUsers = await AsyncStorage.getItem(USERS_DB_KEY);
    let allUsers = savedUsers ? JSON.parse(savedUsers) : [];

    // Check karo ke ye email pehle se register toh nahi hai
    const existingUser = allUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      throw new Error('This email is already registered. Please sign in.');
    }

    // Naya user database mein add karo
    const newUser = { name, email, password };
    allUsers.push(newUser);
    
    // Save karo
    await AsyncStorage.setItem(USERS_DB_KEY, JSON.stringify(allUsers));
    
    // Automatically login karwao
    const demoUser = { name, email };
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(demoUser));
    setUser(demoUser);
    return demoUser;
  };

  // 2. LOGIN
  const login = async (email, password) => {
    if (!email.includes('@')) throw new Error('Enter a valid email.');
    
    // Saare users nikaalo
    const savedUsers = await AsyncStorage.getItem(USERS_DB_KEY);
    let allUsers = savedUsers ? JSON.parse(savedUsers) : [];

    // Check karo ke user exist karta hai aur password match karta hai
    const foundUser = allUsers.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (!foundUser) {
      throw new Error('Invalid credentials. User not found or wrong password.');
    }

    // Agar match ho gaya toh login karwao
    const demoUser = { name: foundUser.name, email: foundUser.email };
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(demoUser));
    setUser(demoUser);
    return demoUser;
  };

  // 3. LOGOUT
  const logout = async () => {
    await AsyncStorage.removeItem(USER_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);