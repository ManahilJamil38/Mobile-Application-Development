import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CartContext = createContext();
const KEY = '@jstrends:cart';

export function CartProvider({ children }) {
  const [items, setItems] = useState([]); 

  useEffect(() => {
    (async () => {
      const saved = await AsyncStorage.getItem(KEY);
      if (saved) setItems(JSON.parse(saved));
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(KEY, JSON.stringify(items));
  }, [items]);

  const addToCart = (product) => {
    setItems((prev) => {
      const existing = prev.find((p) => p.id === product.id);
      if (existing) {
        return prev.map((p) => p.id === product.id ? { ...p, quantity: p.quantity + 1 } : p);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const increaseQty = (id) => setItems((prev) => prev.map((p) => (p.id === id ? { ...p, quantity: p.quantity + 1 } : p)));
  const decreaseQty = (id) => setItems((prev) => prev.map((p) => (p.id === id ? { ...p, quantity: p.quantity - 1 } : p)).filter((p) => p.quantity > 0));
  const removeItem = (id) => setItems((prev) => prev.filter((p) => p.id !== id));
  const clearCart = () => setItems([]);

  const subtotal = items.reduce((sum, p) => sum + p.price * p.quantity, 0);
  const discount = subtotal > 1200 ? Math.round(subtotal * 0.2) : 0;
  const total = subtotal - discount;
  const itemCount = items.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, increaseQty, decreaseQty, removeItem, clearCart, subtotal, discount, total, itemCount }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);