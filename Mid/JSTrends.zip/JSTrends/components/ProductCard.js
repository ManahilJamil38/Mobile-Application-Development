import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, globalStyles } from '../styles/globalStyles';
import { useFavorites } from '../context/FavoritesContext';

export default function ProductCard({ product, onPress, width }) {
  const { favorites, toggleFavorite } = useFavorites();
  const isFav = favorites.some((p) => p.id === product.id);

  return (
    <TouchableOpacity style={[styles.card, width && { width }]} onPress={onPress} activeOpacity={0.85}>
      <View style={styles.imageWrap}>
        <Image source={{ uri: product.image }} style={styles.image} />
        <TouchableOpacity 
          style={styles.heart} 
          onPress={(e) => {
            e.stopPropagation(); 
            toggleFavorite(product);
          }}
        >
          <Ionicons name={isFav ? "heart" : "heart-outline"} size={16} color={isFav ? "red" : colors.text} />
        </TouchableOpacity>
      </View>
      <Text style={styles.name} numberOfLines={1}>{product.name}</Text>
      <Text style={globalStyles.price}>Rs. {product.price.toLocaleString()}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { marginBottom: 20 },
  imageWrap: { borderRadius: 10, overflow: 'hidden', backgroundColor: '#EDE7DA', aspectRatio: 0.85 },
  image: { width: '100%', height: '100%' },
  heart: { position: 'absolute', top: 8, right: 8, width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.9)', alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: 14, fontWeight: '600', color: colors.text, marginTop: 8 },
});