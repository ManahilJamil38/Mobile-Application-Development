import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/globalStyles';

export default function PrimaryButton({ title, onPress, icon, outline = false, style }) {
  return (
    <TouchableOpacity
      style={[outline ? styles.outline : styles.btn, style]}
      onPress={onPress}
      activeOpacity={0.85}
    >
      <Text style={outline ? styles.outlineText : styles.text}>{title}</Text>
      {icon && (
        <Ionicons
          name={icon}
          size={18}
          color={outline ? colors.primary : colors.white}
          style={{ marginLeft: 8 }}
        />
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  btn: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  text: { color: colors.white, fontSize: 15, fontWeight: '600' },
  outline: {
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: colors.primary,
    backgroundColor: 'transparent',
  },
  outlineText: { color: colors.primary, fontSize: 15, fontWeight: '600' },
});