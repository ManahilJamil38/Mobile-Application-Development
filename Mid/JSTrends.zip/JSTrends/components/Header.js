import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { colors, globalStyles } from '../styles/globalStyles';
import { useCart } from '../context/CartContext';

export default function Header({ showBack = false, showMenu = false }) {
  const navigation = useNavigation();
  const { itemCount } = useCart();

  return (
    <View style={styles.wrap}>
      {showBack ? (
        <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={10}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
      ) : showMenu ? (
        <TouchableOpacity onPress={() => navigation.toggleDrawer()} hitSlop={10}>
          <Ionicons name="menu" size={26} color={colors.text} />
        </TouchableOpacity>
      ) : <View style={{ width: 26 }} />}

      <Text style={globalStyles.logo}>J&S Trends</Text>

      <TouchableOpacity onPress={() => navigation.navigate('Cart')} hitSlop={10} style={{ position: 'relative' }}>
        <Ionicons name="bag-handle-outline" size={24} color={colors.text} />
        {/* Cart Badge / Number */}
        {itemCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{itemCount}</Text>
          </View>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14 },
  badge: { position: 'absolute', top: -6, right: -8, backgroundColor: colors.primary, minWidth: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
});