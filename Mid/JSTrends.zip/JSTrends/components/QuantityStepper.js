import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/globalStyles';

export default function QuantityStepper({ quantity, onIncrease, onDecrease }) {
  return (
    <View style={styles.wrap}>
      <TouchableOpacity onPress={onDecrease} hitSlop={8}>
        <Ionicons name="remove" size={16} color={colors.text} />
      </TouchableOpacity>
      <Text style={styles.qty}>{quantity}</Text>
      <TouchableOpacity onPress={onIncrease} hitSlop={8}>
        <Ionicons name="add" size={16} color={colors.text} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1, borderColor: colors.border,
    borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8,
    alignSelf: 'flex-start', gap: 16,
  },
  qty: { fontSize: 14, fontWeight: '600', color: colors.text, minWidth: 16, textAlign: 'center' },
});